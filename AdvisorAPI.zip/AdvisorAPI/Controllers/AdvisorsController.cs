﻿using AdvisorAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AdvisorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdvisorsController : ControllerBase
    {
        private readonly AdvisorDbContext _context;

        public AdvisorsController(AdvisorDbContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<ActionResult<Advisor>> CreateAdvisor(Advisor advisor)
        {

            if (_context.Advisors.Any(a => a.SIN == advisor.SIN))
            {
                return BadRequest();
            }
            if (string.IsNullOrWhiteSpace(advisor.Name))
            {
                return BadRequest("Name is required.");
            }
            if (advisor.SIN.Length != 9)
            {
                return BadRequest("SIN must be exactly 9 characters long.");
            }
            if (_context.Advisors.Any(a => a.SIN == advisor.SIN))
            {
                return BadRequest("SIN must be unique.");
            }
            if (advisor.Phone.Length != 8)
            {
                return BadRequest("Phone number must be exactly 8 characters long.");
            }
            // Generate a random health status
            var random = new Random();
            int healthStatus = random.Next(1, 6);

            advisor.HealthStatus = healthStatus switch
            {
                <= 3 => "Green",
                4 => "Yellow",
                _ => "Red",
            };

            _context.Advisors.Add(advisor);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetAdvisor), new { id = advisor.Id }, advisor);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Advisor>> GetAdvisor(int id)
        {
            var advisor = await _context.Advisors.FindAsync(id);

            if (advisor == null)
            {
                return NotFound();
            }

            return Ok(new
            {
                advisor.Id,
                advisor.Name,
                SIN = advisor.MaskedSIN,
                advisor.Address,
                Phone = advisor.MaskedPhone,
                advisor.HealthStatus
            });
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Advisor>>> GetAdvisors()
        {
            return await _context.Advisors.ToListAsync();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAdvisor(int id, Advisor advisor)
        {
            if (id != advisor.Id)
            {
                return BadRequest();
            }

            var existingAdvisor = await _context.Advisors.FindAsync(id);

            if (existingAdvisor != null)
            {
                _context.Entry(existingAdvisor).State = EntityState.Detached; // Detach existing entity
            }

            _context.Entry(advisor).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Advisors.Any(e => e.Id == id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

                return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAdvisor(int id)
        {
            var advisor = await _context.Advisors.FindAsync(id);
            if (advisor == null)
            {
                return NotFound();
            }

            _context.Advisors.Remove(advisor);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
