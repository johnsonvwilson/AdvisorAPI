﻿namespace AdvisorAPI.Model
{
    public class Advisor
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string SIN { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string HealthStatus { get; set; }


        public string MaskedSIN
        {
            get
            {
                if (SIN?.Length == 9)
                {
                    return "*****" + SIN.Substring(SIN.Length - 4);
                }
                return SIN; // Return as-is if the length is not 9
            }
        }

        // Computed property to mask the Phone
        public string MaskedPhone
        {
            get
            {
                if (Phone?.Length == 8)
                {
                    return "****" + Phone.Substring(Phone.Length - 4);
                }
                return Phone; // Return as-is if the length is not 8
            }
        }
    }
}
