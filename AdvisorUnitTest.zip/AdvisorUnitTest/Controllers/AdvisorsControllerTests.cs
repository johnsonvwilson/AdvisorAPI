﻿using Xunit;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using AdvisorAPI.Controllers;
using AdvisorAPI.Model;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;


public class AdvisorsControllerTests
{
    private readonly AdvisorsController _controller;
    private readonly AdvisorDbContext _context;

    public AdvisorsControllerTests()
    {
        var options = new DbContextOptionsBuilder<AdvisorDbContext>()
            .UseInMemoryDatabase(databaseName: "TestAdvisorDB")
            .Options;

        _context = new AdvisorDbContext(options);
        _controller = new AdvisorsController(_context);

        // Ensure the in-memory database is empty
        _context.Advisors.RemoveRange(_context.Advisors);
        _context.SaveChanges();

        // Seed the database with test data
        _context.Advisors.Add(new Advisor { Id = 1, Name = "John Doe", SIN = "123456789", Address = "123 Street", Phone = "12345678", HealthStatus = "Green" });
        _context.Advisors.Add(new Advisor { Id = 2, Name = "Jane Doe", SIN = "987654321", Address = "456 Avenue", Phone = "87654321", HealthStatus = "Yellow" });
        _context.SaveChanges();
    }

    [Fact]
    public async Task GetAdvisor_ShouldReturnAdvisor_WhenAdvisorExists()
    {
        // Act
        var result = await _controller.GetAdvisor(1);

        // Assert
        var actionResult = Assert.IsType<ActionResult<Advisor>>(result);
        var returnValue = Assert.IsType<Advisor>(actionResult.Value);
        Assert.Equal("John Doe", returnValue.Name);
    }

    [Fact]
    public async Task GetAdvisor_ShouldReturnNotFound_WhenAdvisorDoesNotExist()
    {
        // Act
        var result = await _controller.GetAdvisor(99);

        // Assert
        Assert.IsType<NotFoundResult>(result.Result);
    }

    [Fact]
    public async Task CreateAdvisor_ShouldReturnCreatedAdvisor()
    {
        // Arrange
        var advisor = new Advisor { Name = "Test Advisor", SIN = "111222333", Address = "789 Road", Phone = "11223344" };

        // Act
        var result = await _controller.CreateAdvisor(advisor);

        // Assert
        var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result.Result);
        var returnValue = Assert.IsType<Advisor>(createdAtActionResult.Value);
        Assert.Equal("Test Advisor", returnValue.Name);
    }

    [Fact]
    public async Task CreateAdvisor_ShouldReturnBadRequest_WhenSINIsNotUnique()
    {
        // Arrange
        var advisor = new Advisor { Name = "Duplicate SIN", SIN = "123456789", Address = "Some Address", Phone = "12345678" };

        // Act
        var result = await _controller.CreateAdvisor(advisor);

        // Assert
        Assert.IsType<BadRequestResult>(result.Result);
    }

    [Fact]
    public async Task UpdateAdvisor_ShouldReturnNoContent_WhenAdvisorIsUpdatedSuccessfully()
    {
        // Arrange
        var advisor = new Advisor { Id = 1, Name = "Updated Name", SIN = "123456789", Address = "Updated Address", Phone = "12345678", HealthStatus = "Green" };

        // Act
        var result = await _controller.UpdateAdvisor(1, advisor);

        // Assert
        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task UpdateAdvisor_ShouldReturnBadRequest_WhenIdDoesNotMatch()
    {
        // Arrange
        var advisor = new Advisor { Id = 2, Name = "Wrong ID", SIN = "987654321", Address = "Some Address", Phone = "87654321", HealthStatus = "Yellow" };

        // Act
        var result = await _controller.UpdateAdvisor(1, advisor);

        // Assert
        Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public async Task DeleteAdvisor_ShouldReturnNoContent_WhenAdvisorIsDeletedSuccessfully()
    {
        // Act
        var result = await _controller.DeleteAdvisor(1);

        // Assert
        Assert.IsType<NoContentResult>(result);

        // Verify that the advisor was deleted
        var advisor = await _context.Advisors.FindAsync(1);
        Assert.Null(advisor);
    }

    [Fact]
    public async Task DeleteAdvisor_ShouldReturnNotFound_WhenAdvisorDoesNotExist()
    {
        // Act
        var result = await _controller.DeleteAdvisor(99);

        // Assert
        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task GetAdvisors_ShouldReturnAllAdvisors()
    {
        // Act
        var result = await _controller.GetAdvisors();

        // Assert
        var actionResult = Assert.IsType<ActionResult<IEnumerable<Advisor>>>(result);
        var returnValue = Assert.IsType<List<Advisor>>(actionResult.Value);
        Assert.Equal(2, returnValue.Count);
    }

    [Fact]
    public async Task CreateAdvisor_ShouldReturnBadRequest_WhenNameIsNull()
    {
        // Arrange
        var advisor = new Advisor { SIN = "444555666", Address = "Some Address", Phone = "33445566" };

        // Act
        var result = await _controller.CreateAdvisor(advisor);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Equal("Name is required.", badRequestResult.Value);
    }

    [Fact]
    public async Task CreateAdvisor_ShouldReturnBadRequest_WhenSINIsInvalidLength()
    {
        // Arrange
        var advisor = new Advisor { Id = 14, Name = "Invalid SIN", SIN = "123", Address = "Some Address", Phone = "12345678" };

        // Act
        var result = await _controller.CreateAdvisor(advisor);

        // Assert
        //Assert.IsType<BadRequestResult>(result.Result);
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Equal("SIN must be exactly 9 characters long.", badRequestResult.Value);
    }

    [Fact]
    public async Task CreateAdvisor_ShouldReturnBadRequest_WhenSINIsNotExactly9Characters()
    {
        // Arrange
        var advisor = new Advisor
        {
            Id = 25,
            Name = "Test Advisor",
            SIN = "1234", // Invalid SIN length
            Address = "789 Road",
            Phone = "87654321"
        };

        // Act
        var result = await _controller.CreateAdvisor(advisor);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestResult>(result.Result);
      
    }

    [Fact]
    public async Task GetAdvisor_ShouldReturnMaskedSINAndPhone_WhenAdvisorExists()
    {
        // Act
        var result = await _controller.GetAdvisor(1);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var advisor = Assert.IsType<dynamic>(okResult.Value);

        Assert.Equal("*****6789", advisor.MaskedSIN);
        Assert.Equal("****5678", advisor.MaskedPhone);
    }

    [Fact]
    public async Task CreateAdvisor_ShouldStoreFullSINAndPhoneCorrectly()
    {
        // Arrange
        var advisor = new Advisor
        {
            Name = "Test Advisor",
            SIN = "123456789",
            Address = "789 Road",
            Phone = "87654321"
        };

        // Act
        var result = await _controller.CreateAdvisor(advisor);

        // Assert
        var createdAtActionResult = Assert.IsType<BadRequestObjectResult>(result.Result);
        var createdAdvisor = Assert.IsType<Advisor>(createdAtActionResult.Value);

        Assert.Equal("123456789", createdAdvisor.SIN);
        Assert.Equal("87654321", createdAdvisor.Phone);
    }

    [Fact]
    public async Task GetAdvisors_ShouldReturnMaskedSINAndPhone()
    {
        // Act
        var result = await _controller.GetAdvisors();

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var advisors = Assert.IsType<List<dynamic>>(okResult.Value);

        Assert.All(advisors, advisor =>
        {
            Assert.Matches(@"^\*{5}\d{4}$", advisor.MaskedSIN);
            Assert.Matches(@"^\*{4}\d{4}$", advisor.MaskedPhone);
        });
    }


 

    [Fact]
    public async Task CreateAdvisor_ShouldReturnBadRequest_WhenPhoneIsNotExactly8Characters()
    {
        // Arrange
        var advisor = new Advisor
        {
            Name = "Test Advisor",
            SIN = "123456789",
            Address = "789 Road",
            Phone = "12345" // Invalid Phone length
        };

        // Act
        var result = await _controller.CreateAdvisor(advisor);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Equal("Phone number must be exactly 8 characters long.", badRequestResult.Value);
    }

    [Fact]
    public async Task UpdateAdvisor_ShouldStoreUnmaskedSINAndPhone()
    {
        // Arrange
        var advisor = new Advisor
        {
            Id = 1,
            Name = "Updated Name",
            SIN = "987654321",
            Address = "Updated Address",
            Phone = "87654321",
            HealthStatus = "Green"
        };

        // Act
        var result = await _controller.UpdateAdvisor(1, advisor);

        // Assert
        Assert.IsType<NoContentResult>(result);

        var updatedAdvisor = await _context.Advisors.FindAsync(1);
        Assert.Equal("987654321", updatedAdvisor.SIN);
        Assert.Equal("87654321", updatedAdvisor.Phone);
    }


    [Fact]
    public async Task CreateAdvisor_ShouldReturnBadRequest_WhenNameIsWhitespace()
    {
        // Arrange
        var advisor = new Advisor
        {
            Name = "", // Invalid Name
            SIN = "123456789",
            Address = "789 Road",
            Phone = "87654321"
        };

        // Act
        var result = await _controller.CreateAdvisor(advisor);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result.Result);
        Assert.Equal("Name is required.", badRequestResult.Value);
    }


}
